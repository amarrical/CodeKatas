Welcome to the dice program again!

Requirements:

Menu options:
1. Roll the cup of dice (returns number of dice rolled and total of all dice).
2. Add a die.
	2.1 Regular die.
		2.1.1 Number of sides.
	2.2 Loaded die.
		2.2.1 Number of sides.
		2.2.2 Loaded value.
3. Empty the cup.

Those are all the requirements.  Language is open, UI is open, do whatever you want.